#include <iostream>
#include <chrono>
#include <array>
#include <cstdlib>
#include "net.h"

using namespace std;

/** This is an artificial neural network that is trained to act like a NAND gate.
 * It uses a weighted sum function as the input function and the Sigmoid function
 * as the activation function. The squared error function is used to calculate
 * the error and back-propagation is executed with a learning rate of 0.5.
 * The structure of the ANN is 2x5x1.
 *
 * @author Dylan & Yansan
 * @course COSC 3P93
 */
int main(int argc,char* argv[]) {
  int const numberNetWork = 1000;

  int thread_count = 1;
  if(argc>1) thread_count = stoi(argv[1]);

  auto start = chrono::system_clock::now();
  srand(311);

  array<array<double,2>,4> inputs = {{{0,0},{0,1},{1,0},{1,1}}}; //set of inputs
  array<double,4> targets = {1,1,1,0};  //set of target output values
  array<array<double,2>,5> hidden1; //weights from input layer to hidden
  array<double,5> hidden2;  //weights from hidden layer to output
  array<double,2> bias; //bias for each set of weights

  array<NeuralNet*, numberNetWork> networks;

  double weight;
  double bestAvgError = 1000000;
  int bestNetwork;
  //Initialize Neural networks

  for(int i=0; i<numberNetWork; i++){
    //Randomly initialize weights to values [-0.5,0.5]
    for(int j=0; j<5; j++){
      for(int k=0; k<2; k++){
        weight = rand() % 100000000;
        weight = (weight / 100000000) - 0.5;
        hidden1.at(j).at(k) = weight;
      }
    }
    for(int j=0; j<5; j++){
      weight = rand() % 100000000;
      weight = (weight / 100000000) - 0.5;
      hidden2.at(j) = weight;
    }
    for(int j=0; j<2; j++){
      weight = rand() % 100000000;
      weight = (weight / 100000000) - 0.5;
      bias.at(j) = weight;
    }
    networks.at(i) = new NeuralNet(inputs.at(0), hidden1, hidden2, targets.at(0), bias);
    // networks.at(bestNetwork)->setBias(bias);
  }

  //Train Neural Network
  double avgErr;
  int testSet = rand() % 4;
  #pragma omp parallel for num_threads(thread_count)
  for(int i=0; i<numberNetWork; i++){
    for(int j=0; j<5000; j++){
      networks.at(i)->setInputs(inputs.at(testSet));
      networks.at(i)->setTarget(targets.at(testSet));
      networks.at(i)->train();
      testSet = rand() % 4;
    }
    avgErr = networks.at(i)->getAvgError();
    #pragma omp critical
    if(avgErr < bestAvgError){
      bestAvgError = avgErr;
      bestNetwork = i;
    }
  }

  //Test Best Neural Network
  double avgError = 0;
  cout<<"Best Network: "<<bestNetwork<<endl;
  cout<<"Inputs (0,0)"<<endl;
  cout<<"Expected Output: 1"<<endl;
  networks.at(bestNetwork)->setInputs(inputs.at(0));
  networks.at(bestNetwork)->setTarget(targets.at(0));
  avgError += networks.at(bestNetwork)->testWithOutput();
  cout<<"Inputs (0,1)"<<endl;
  cout<<"Expected Output: 1"<<endl;
  networks.at(bestNetwork)->setInputs(inputs.at(1));
  networks.at(bestNetwork)->setTarget(targets.at(1));
  avgError += networks.at(bestNetwork)->testWithOutput();
  cout<<"Inputs (1,0)"<<endl;
  cout<<"Expected Output: 1"<<endl;
  networks.at(bestNetwork)->setInputs(inputs.at(2));
  networks.at(bestNetwork)->setTarget(targets.at(2));
  avgError += networks.at(bestNetwork)->testWithOutput();
  cout<<"Inputs (1,1)"<<endl;
  cout<<"Expected Output: 0"<<endl;
  networks.at(bestNetwork)->setInputs(inputs.at(3));
  networks.at(bestNetwork)->setTarget(targets.at(3));
  avgError += networks.at(bestNetwork)->testWithOutput();
  avgError = avgError/4;
  cout<<"Average Error: "<<avgError<<endl;

  auto end = chrono::system_clock::now();
  chrono::duration<double> runtime = end-start;
  cout<<"Elapsed Time: "<<runtime.count()<<"s\n";
}
